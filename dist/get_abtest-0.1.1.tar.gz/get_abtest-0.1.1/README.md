# get_abtest
Hello everyone,
this is a customized ab test frame work package
For time to time, I realize that there is a need to run hypothsis test on ab testing experiment
So I tried to build a python modules to automative the work a little bit
Hope everyone who see this enjoy it :) 
